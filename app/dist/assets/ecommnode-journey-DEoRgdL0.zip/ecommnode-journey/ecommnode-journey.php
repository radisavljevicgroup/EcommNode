<?php
/**
 * Plugin Name:       ecommnode – Put kupca
 * Description:       Anonimno praćenje puta kupca do porudžbine (samo uz pristanak, bez ličnih podataka) za ecommnode dashboard.
 * Version:           0.1.5
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            ecommnode
 * Author URI:        https://ecommnode.com
 * Text Domain:       ecommnode-journey
 * WC requires at least: 7.0
 */

defined( 'ABSPATH' ) || exit;

define( 'ECJ_VERSION', '0.1.5' );
define( 'ECJ_FILE', __FILE__ );

require_once __DIR__ . '/includes/settings.php';

// Kolačići koje plugin postavlja (samo posle pristanka, osim ecj_consent koji
// pamti sam izbor posetioca).
const ECJ_COOKIE_SESSION = 'ecj_sid';
const ECJ_COOKIE_PURCHASE = 'ecj_po';
const ECJ_ORDER_META = '_journey_session_id';

function ecj_defaults() {
	return array(
		'enabled'      => 0,
		'endpoint'     => 'https://api.ecommnode.com',
		'shop_key'     => '',
		'consent'      => 'auto',
		'cookie_name'  => '',
		'cookie_match' => '',
		'banner_title' => '',
		'banner_text'  => '',
		'policy_url'   => '',
		'style'        => array(),
		'custom_css'   => '',
		'footer_link'  => '',
		'footer_text'  => '',
		'selectors'    => '',
	);
}

function ecj_options() {
	return wp_parse_args( (array) get_option( 'ecj_settings', array() ), ecj_defaults() );
}

function ecj_is_active() {
	$o = ecj_options();
	return ! empty( $o['enabled'] ) && ! empty( $o['shop_key'] ) && ! empty( $o['endpoint'] );
}

// HPOS (WooCommerce tabele porudžbina) — plugin piše meta samo preko
// WC_Order API-ja, pa radi sa oba načina čuvanja.
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', ECJ_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', ECJ_FILE, true );
		}
	}
);

// ---------------------------------------------------------------------------
// Tip stranice i podaci koje tracker ne može sam da zna.

function ecj_page_type() {
	if ( is_front_page() ) {
		return 'home';
	}
	if ( function_exists( 'is_woocommerce' ) ) {
		if ( is_search() ) {
			return 'search';
		}
		if ( is_product() ) {
			return 'product';
		}
		if ( is_shop() || is_product_taxonomy() ) {
			return 'collection';
		}
		if ( is_cart() ) {
			return 'cart';
		}
		if ( is_checkout() ) {
			return 'checkout';
		}
	}
	return is_search() ? 'search' : 'other';
}

function ecj_parse_selectors( $raw ) {
	$allowed = array( 'card', 'title', 'search', 'banner', 'related', 'footer', 'menu', 'section' );
	$out     = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		if ( ! preg_match( '/^\s*([a-z]+)\s*=\s*(.+?)\s*$/', $line, $m ) ) {
			continue;
		}
		if ( in_array( $m[1], $allowed, true ) ) {
			$out[ $m[1] ] = $m[2];
		}
	}
	return $out;
}

function ecj_page_config() {
	$o = ecj_options();
	$c = array(
		'key'      => $o['shop_key'],
		'endpoint' => untrailingslashit( $o['endpoint'] ) . '/collect',
		'pt'       => ecj_page_type(),
		'consent'  => $o['consent'],
	);

	if ( 'auto' === $c['consent'] ) {
		$c['consent'] = function_exists( 'wp_has_consent' ) ? 'wpconsent' : 'banner';
	}
	if ( 'cookie' === $c['consent'] ) {
		$c['cn'] = $o['cookie_name'];
		$c['cm'] = $o['cookie_match'];
	}
	if ( 'banner' === $c['consent'] ) {
		if ( $o['banner_title'] ) {
			$c['btt'] = $o['banner_title'];
		}
		if ( $o['banner_text'] ) {
			$c['bt'] = $o['banner_text'];
		}
		$c['sn'] = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		if ( $o['style'] ) {
			$c['th'] = $o['style'];
		}
		if ( $o['footer_link'] ) {
			$c['fl'] = $o['footer_link'];
			if ( $o['footer_text'] ) {
				$c['flt'] = $o['footer_text'];
			}
		}
		if ( $o['custom_css'] ) {
			$c['css'] = $o['custom_css'];
		}
		$policy = $o['policy_url'] ? $o['policy_url'] : get_privacy_policy_url();
		if ( $policy ) {
			$c['pu'] = $policy;
		}
	}

	$sel = ecj_parse_selectors( $o['selectors'] );
	if ( $sel ) {
		$c['sel'] = $sel;
	}

	if ( function_exists( 'is_product' ) && is_product() ) {
		$product = wc_get_product( get_queried_object_id() );
		if ( $product ) {
			$c['pid']   = (string) $product->get_id();
			$c['pname'] = $product->get_name();
			$c['price'] = (float) wc_get_price_to_display( $product );
		}
	}

	if ( in_array( $c['pt'], array( 'collection', 'search' ), true ) ) {
		$term = get_queried_object();
		if ( $term instanceof WP_Term ) {
			$c['list'] = $term->name;
		} elseif ( function_exists( 'is_shop' ) && is_shop() ) {
			$c['list'] = get_the_title( wc_get_page_id( 'shop' ) );
		}
		$paged    = max( 1, (int) get_query_var( 'paged' ) );
		$per_page = (int) get_query_var( 'posts_per_page' );
		if ( $paged > 1 && $per_page > 0 ) {
			$c['off'] = ( $paged - 1 ) * $per_page;
		}
	}

	if ( is_search() ) {
		$c['st'] = get_search_query( false );
	}

	if ( 'checkout' === $c['pt'] && function_exists( 'WC' ) && WC()->cart ) {
		$c['cart'] = (float) WC()->cart->get_total( 'edit' );
	}

	return $c;
}

// ---------------------------------------------------------------------------
// Skripta: defer, u futeru, konfiguracija inline ispred nje.

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! ecj_is_active() ) {
			return;
		}
		wp_register_script(
			'ecj-tracker',
			plugins_url( 'assets/tracker.min.js', ECJ_FILE ),
			array(),
			ECJ_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);
		wp_add_inline_script( 'ecj-tracker', 'window.ecjCfg=' . wp_json_encode( ecj_page_config() ) . ';', 'before' );
		wp_enqueue_script( 'ecj-tracker' );
	}
);

// Keš/optimizacioni pluginovi: tracker je već mali i defer — ne spajati ga sa
// drugim skriptama i ne odlagati do interakcije (izgubio bi se page_view
// posetilaca koji odmah odu i dubina skrola).
$ecj_js_exclusions = function ( $list ) {
	return array_merge( (array) $list, array( 'ecommnode-journey', 'ecjCfg' ) );
};
add_filter( 'litespeed_optimize_js_excludes', $ecj_js_exclusions );
add_filter( 'litespeed_optm_js_defer_exc', $ecj_js_exclusions );
add_filter( 'litespeed_optm_gm_js_exc', $ecj_js_exclusions );
add_filter( 'rocket_exclude_js', $ecj_js_exclusions );
add_filter( 'rocket_exclude_defer_js', $ecj_js_exclusions );
add_filter( 'rocket_delay_js_exclusions', $ecj_js_exclusions );
add_filter( 'rocket_exclude_inline_js', $ecj_js_exclusions );

// ---------------------------------------------------------------------------
// Porudžbina: session_id u meta + kolačić za purchase događaj.

function ecj_current_session_id() {
	$sid = isset( $_COOKIE[ ECJ_COOKIE_SESSION ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ ECJ_COOKIE_SESSION ] ) ) : '';
	return preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $sid ) ? strtolower( $sid ) : '';
}

// Kolačić ecj_sid postoji samo ako je posetilac dao pristanak (tracker ga
// postavlja tek posle pristanka), pa porudžbina bez pristanka nikad ne dobija
// meta i u ecommnode-u ostaje "nepoznato (bez pristanka)".
function ecj_attach_session( $order ) {
	if ( ! ecj_is_active() || ! $order instanceof WC_Order ) {
		return;
	}
	$sid = ecj_current_session_id();
	if ( $sid ) {
		$order->update_meta_data( ECJ_ORDER_META, $sid );
	}
}
add_action( 'woocommerce_checkout_create_order', 'ecj_attach_session', 10, 1 );
add_action(
	'woocommerce_store_api_checkout_update_order_meta',
	function ( $order ) {
		ecj_attach_session( $order );
	}
);

// purchase događaj šalje tracker na sledećoj učitanoj stranici (zahvalnica —
// bilo WooCommerce-ova, bilo FunnelKit/prilagođena), iz ovog kratkotrajnog
// kolačića. Ne zavisi od toga kako tema prikazuje zahvalnicu.
function ecj_mark_purchase( $order ) {
	if ( ! ecj_is_active() || ! $order instanceof WC_Order || ! ecj_current_session_id() || headers_sent() ) {
		return;
	}
	$value = implode(
		'|',
		array(
			$order->get_id(),
			wc_format_decimal( $order->get_total(), 2 ),
			$order->get_currency(),
			$order->get_item_count(),
		)
	);
	setcookie(
		ECJ_COOKIE_PURCHASE,
		$value,
		array(
			'expires'  => time() + 600,
			'path'     => '/',
			'secure'   => is_ssl(),
			'httponly' => false,
			'samesite' => 'Lax',
		)
	);
}
add_action(
	'woocommerce_checkout_order_processed',
	function ( $order_id ) {
		ecj_mark_purchase( wc_get_order( $order_id ) );
	},
	10,
	1
);
add_action( 'woocommerce_store_api_checkout_order_processed', 'ecj_mark_purchase' );

// ---------------------------------------------------------------------------
// WP Consent API: plugin se prijavljuje kao usklađen i opisuje svoje kolačiće.

add_filter( 'wp_consent_api_registered_' . plugin_basename( ECJ_FILE ), '__return_true' );
add_action(
	'plugins_loaded',
	function () {
		if ( ! function_exists( 'wp_add_cookie_info' ) ) {
			return;
		}
		wp_add_cookie_info( ECJ_COOKIE_SESSION, 'ecommnode – Put kupca', 'statistics', '30 minuta', 'Anonimni identifikator posete (bez ličnih podataka).' );
		wp_add_cookie_info( ECJ_COOKIE_PURCHASE, 'ecommnode – Put kupca', 'statistics', '10 minuta', 'Broj porudžbine za anonimnu statistiku kupovine.' );
		wp_add_cookie_info( 'ecj_consent', 'ecommnode – Put kupca', 'functional', 'trajno (obnavlja se, najviše 400 dana)', 'Pamti izbor posetioca o statistici.' );
	}
);

// [ecj_consent_link] — link za promenu/povlačenje pristanka (staviti u futer
// ili u politiku privatnosti). Otvara isti baner; izbor se ponovo pamti.
add_shortcode(
	'ecj_consent_link',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'text' => 'Podešavanja kolačića' ), $atts, 'ecj_consent_link' );
		return '<a href="#" class="ecj-consent-link" onclick="if(window.ecjReopen){window.ecjReopen();}return false;">' . esc_html( $atts['text'] ) . '</a>';
	}
);

add_filter(
	'plugin_action_links_' . plugin_basename( ECJ_FILE ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=ecommnode-journey' ) ) . '">Podešavanja</a>' );
		return $links;
	}
);
