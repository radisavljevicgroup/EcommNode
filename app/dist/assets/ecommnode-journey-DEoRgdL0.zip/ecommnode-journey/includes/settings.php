<?php
// Podešavanja → ecommnode Put kupca.
defined( 'ABSPATH' ) || exit;

// Gotove postavke za česte cookie pluginove (režim "cookie"): ime kolačića i
// regex koji znači "statistika dozvoljena".
function ecj_cookie_presets() {
	return array(
		'complianz' => array( 'Complianz', 'cmplz_statistics', '^allow$' ),
		'cookieyes' => array( 'CookieYes', 'cookieyes-consent', 'analytics:yes' ),
		'cookiebot' => array( 'Cookiebot', 'CookieConsent', 'statistics:true' ),
		'borlabs'   => array( 'Borlabs Cookie', 'borlabs-cookie', 'statistics' ),
	);
}

// Polja stila banera: ključ => [oznaka, tip, podrazumevano]. Ključevi su isti
// kao THEME u assets/tracker.src.js.
function ecj_style_fields() {
	return array(
		'ac' => array( 'Linija na vrhu', 'color', '#fe5000' ),
		'tc' => array( 'Naslov', 'color', 'kao linija' ),
		'xc' => array( 'Tekst', 'color', '#757575' ),
		'bc' => array( '„Slažem se“ – pozadina', 'color', '#ffcb48' ),
		'bt' => array( '„Slažem se“ – tekst', 'color', '#2d2926' ),
		'dc' => array( 'Ostala dugmad – tekst', 'color', '#2d2926' ),
		'lc' => array( 'Ostala dugmad – okvir', 'color', '#c4c7ca' ),
		'ov' => array( 'Zatamnjenje pozadine', 'color', 'rgba(45,41,38,.35)' ),
		'r'  => array( 'Zaobljenje dugmadi', 'px', '4 (999 = pilula)' ),
		'pr' => array( 'Zaobljenje panela (gore)', 'px', '0' ),
	);
}

add_action(
	'admin_menu',
	function () {
		add_options_page( 'ecommnode – Put kupca', 'ecommnode Put kupca', 'manage_options', 'ecommnode-journey', 'ecj_render_settings' );
	}
);

add_action(
	'admin_init',
	function () {
		register_setting(
			'ecj_settings_group',
			'ecj_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => 'ecj_sanitize_settings',
				'default'           => ecj_defaults(),
			)
		);
	}
);

function ecj_sanitize_settings( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$out = ecj_defaults();

	$out['enabled']  = empty( $in['enabled'] ) ? 0 : 1;
	$out['endpoint'] = esc_url_raw( trim( (string) ( $in['endpoint'] ?? '' ) ), array( 'https', 'http' ) );
	$out['shop_key'] = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $in['shop_key'] ?? '' ) );

	$consent        = (string) ( $in['consent'] ?? 'auto' );
	$out['consent'] = in_array( $consent, array( 'auto', 'wpconsent', 'banner', 'cookie' ), true ) ? $consent : 'auto';

	$preset = (string) ( $in['cookie_preset'] ?? '' );
	$p      = ecj_cookie_presets();
	if ( isset( $p[ $preset ] ) ) {
		$out['cookie_name']  = $p[ $preset ][1];
		$out['cookie_match'] = $p[ $preset ][2];
	} else {
		$out['cookie_name']  = sanitize_text_field( (string) ( $in['cookie_name'] ?? '' ) );
		$out['cookie_match'] = (string) ( $in['cookie_match'] ?? '' );
		if ( '' !== $out['cookie_match'] && false === @preg_match( '/' . str_replace( '/', '\/', $out['cookie_match'] ) . '/', '' ) ) {
			add_settings_error( 'ecj_settings', 'ecj_regex', 'Uslov za kolačić nije ispravan regularni izraz.' );
			$out['cookie_match'] = '';
		}
	}

	$out['banner_title'] = sanitize_text_field( (string) ( $in['banner_title'] ?? '' ) );
	$out['banner_text']  = sanitize_textarea_field( (string) ( $in['banner_text'] ?? '' ) );
	$out['style'] = array();
	foreach ( ecj_style_fields() as $key => $field ) {
		$value = trim( (string) ( $in['style'][ $key ] ?? '' ) );
		if ( '' === $value ) {
			continue;
		}
		if ( 'px' === $field[1] ) {
			$out['style'][ $key ] = (string) min( 999, absint( $value ) );
		} elseif ( preg_match( '/^(#[0-9a-f]{3,8}|rgba?\([\d\s.,%]+\))$/i', $value ) ) {
			$out['style'][ $key ] = $value;
		}
	}
	// Dodatni CSS za #ecj-banner — bez mogućnosti da zatvori <style> tag.
	$out['custom_css'] = str_replace( array( '<', '>' ), '', wp_strip_all_tags( (string) ( $in['custom_css'] ?? '' ) ) );
	$out['footer_link'] = sanitize_text_field( (string) ( $in['footer_link'] ?? '' ) );
	$out['footer_text'] = sanitize_text_field( (string) ( $in['footer_text'] ?? '' ) );
	$out['policy_url']  = esc_url_raw( (string) ( $in['policy_url'] ?? '' ) );
	$out['selectors']   = sanitize_textarea_field( (string) ( $in['selectors'] ?? '' ) );

	if ( $out['enabled'] && ( ! $out['shop_key'] || ! $out['endpoint'] ) ) {
		add_settings_error( 'ecj_settings', 'ecj_missing', 'Za uključivanje su potrebni ecommnode URL i ključ prodavnice.' );
		$out['enabled'] = 0;
	}
	return $out;
}

function ecj_render_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o       = ecj_options();
	$name    = 'ecj_settings';
	$has_api = function_exists( 'wp_has_consent' );
	?>
	<div class="wrap">
		<h1>ecommnode – Put kupca</h1>
		<p>Anonimno beleži put posetioca do porudžbine (izvor, meni, kategorija, pozicija u listi, korpa) i šalje ga direktno na ecommnode.
			Radi samo uz pristanak posetioca, ne čuva IP, ime, mejl, telefon ni sadržaj formi. Događaji se brišu posle 90 dana.</p>
		<?php settings_errors( 'ecj_settings' ); ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'ecj_settings_group' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Uključeno</th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[enabled]" value="1" <?php checked( $o['enabled'], 1 ); ?>> Prati put kupca</label></td>
				</tr>
				<tr>
					<th scope="row"><label for="ecj-endpoint">ecommnode URL</label></th>
					<td><input id="ecj-endpoint" class="regular-text" type="url" name="<?php echo esc_attr( $name ); ?>[endpoint]" value="<?php echo esc_attr( $o['endpoint'] ); ?>">
						<p class="description">Adresa ecommnode API servera, npr. https://api.ecommnode.com</p></td>
				</tr>
				<tr>
					<th scope="row"><label for="ecj-key">Ključ prodavnice</label></th>
					<td><input id="ecj-key" class="regular-text code" type="text" name="<?php echo esc_attr( $name ); ?>[shop_key]" value="<?php echo esc_attr( $o['shop_key'] ); ?>" placeholder="enj_…">
						<p class="description">Iz ecommnode dashboard-a (Put kupca → Prodavnice). Domen ovog sajta mora biti dozvoljen za taj ključ.</p></td>
				</tr>
				<tr>
					<th scope="row">Pristanak</th>
					<td>
						<?php
						$modes = array(
							'auto'      => 'Automatski — WP Consent API ako postoji, inače ugrađeni baner',
							'wpconsent' => 'WP Consent API (kategorija „statistics“)' . ( $has_api ? '' : ' — nije instaliran' ),
							'banner'    => 'Ugrađeni baner (Prihvatam / Odbijam)',
							'cookie'    => 'Postojeći cookie plugin (čita njegov kolačić)',
						);
						foreach ( $modes as $value => $label ) {
							printf(
								'<label style="display:block;margin-bottom:4px"><input type="radio" name="%s[consent]" value="%s" %s> %s</label>',
								esc_attr( $name ),
								esc_attr( $value ),
								checked( $o['consent'], $value, false ),
								esc_html( $label )
							);
						}
						?>
						<p class="description">Bez pristanka tracker ne postavlja nijedan kolačić osim pamćenja samog izbora i ništa ne šalje.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Cookie plugin</th>
					<td>
						<select name="<?php echo esc_attr( $name ); ?>[cookie_preset]">
							<option value="">— ručno —</option>
							<?php foreach ( ecj_cookie_presets() as $key => $p ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $o['cookie_name'], $p[1] ); ?>><?php echo esc_html( $p[0] ); ?></option>
							<?php endforeach; ?>
						</select>
						<p><input class="regular-text code" type="text" name="<?php echo esc_attr( $name ); ?>[cookie_name]" value="<?php echo esc_attr( $o['cookie_name'] ); ?>" placeholder="ime kolačića"></p>
						<p><input class="regular-text code" type="text" name="<?php echo esc_attr( $name ); ?>[cookie_match]" value="<?php echo esc_attr( $o['cookie_match'] ); ?>" placeholder="regex za „dozvoljeno“"></p>
						<p class="description">Samo za režim „Postojeći cookie plugin“.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ecj-bt">Baner</label></th>
					<td><p><input class="regular-text" type="text" name="<?php echo esc_attr( $name ); ?>[banner_title]" value="<?php echo esc_attr( $o['banner_title'] ); ?>" placeholder="Obaveštenje o kolačićima"></p>
						<textarea id="ecj-bt" class="large-text" rows="2" name="<?php echo esc_attr( $name ); ?>[banner_text]" placeholder="Za vreme korišćenja bilo koje stranice na veb-sajtu <?php echo esc_attr( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?>, kompanija <?php echo esc_attr( get_bloginfo( 'name' ) ); ?> može da sačuva određene informacije na korisnikov uređaj, putem „kolačića“ (eng. „cookies“)."><?php echo esc_textarea( $o['banner_text'] ); ?></textarea>
						<details style="margin-top:8px"<?php echo $o['style'] ? ' open' : ''; ?>>
							<summary>Stil banera (boje, zaobljenja)</summary>
							<p class="description">Prazno = podrazumevano. Boje kao #1f2a48 ili rgba(31,42,72,.4).</p>
							<table>
								<?php foreach ( ecj_style_fields() as $key => $field ) : ?>
									<tr>
										<td><label for="ecj-st-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field[0] ); ?></label></td>
										<td><input id="ecj-st-<?php echo esc_attr( $key ); ?>" class="code" type="text" size="22" name="<?php echo esc_attr( $name ); ?>[style][<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $o['style'][ $key ] ?? '' ); ?>" placeholder="<?php echo esc_attr( $field[2] ); ?>"> <?php echo 'px' === $field[1] ? 'px' : ''; ?></td>
									</tr>
								<?php endforeach; ?>
							</table>
							<p><label for="ecj-css">Dodatni CSS (selektor <code>#ecj-banner</code>)</label><br>
								<textarea id="ecj-css" class="large-text code" rows="3" name="<?php echo esc_attr( $name ); ?>[custom_css]"><?php echo esc_textarea( $o['custom_css'] ); ?></textarea></p>
						</details>
						<p class="description">Izbor posetioca (prihvatanje ili odbijanje) pamti se trajno — baner se više ne prikazuje. Prazna polja = podrazumevani tekst.</p>
						<p><input class="regular-text" type="url" name="<?php echo esc_attr( $name ); ?>[policy_url]" value="<?php echo esc_attr( $o['policy_url'] ); ?>" placeholder="link ka politici privatnosti (podrazumevano: WordPress stranica privatnosti)"></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="ecj-fl">Link u futeru</label></th>
					<td><input id="ecj-fl" class="regular-text code" type="text" name="<?php echo esc_attr( $name ); ?>[footer_link]" value="<?php echo esc_attr( $o['footer_link'] ); ?>" placeholder="npr. footer .widget_nav_menu ul">
						<input class="regular-text" type="text" name="<?php echo esc_attr( $name ); ?>[footer_text]" value="<?php echo esc_attr( $o['footer_text'] ); ?>" placeholder="Podešavanja kolačića">
						<p class="description">CSS selektor dela futera u koji plugin sam ubacuje link za promenu/povlačenje pristanka (ako je to lista, dodaje se kao nova stavka). Alternativa: kratki kod <code>[ecj_consent_link]</code> u widget futera.</p></td>
				</tr>
				<tr>
					<th scope="row"><label for="ecj-sel">Selektori teme</label></th>
					<td><textarea id="ecj-sel" class="large-text code" rows="6" name="<?php echo esc_attr( $name ); ?>[selectors]" placeholder="card = li.product, .pcard&#10;menu = header, nav&#10;banner = .hero-slider"><?php echo esc_textarea( $o['selectors'] ); ?></textarea>
						<p class="description">Neobavezno. Po jedan red <code>ključ = CSS selektor</code>; ključevi: card, title, search, banner, related, footer, menu, section.
							Elementi sa atributima <code>data-track-location</code> / <code>data-track-position</code> uvek imaju prednost.</p></td>
				</tr>
			</table>
			<?php submit_button( 'Sačuvaj' ); ?>
		</form>
	</div>
	<?php
}
